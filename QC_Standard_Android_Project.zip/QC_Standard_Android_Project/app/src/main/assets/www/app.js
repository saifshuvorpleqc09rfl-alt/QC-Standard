(() => {
 const $ = id => document.getElementById(id);
 const status = $('status'), items = $('items'), panel = $('adminPanel');
 let client = null, session = null, standards = [];
 const configured = window.QC_CONFIG && !window.QC_CONFIG.SUPABASE_URL.includes('YOUR-PROJECT') && !window.QC_CONFIG.SUPABASE_ANON_KEY.includes('YOUR_');

 function showStatus(msg){status.textContent=msg}
 function render(){
   const q=$('search').value.toLowerCase();
   const visible=standards.filter(x => (x.title+' '+x.category+' '+x.details).toLowerCase().includes(q));
   items.innerHTML='';
   if(!visible.length){items.innerHTML='<div class="item"><p>No published standards yet. Admin can add the first standard after setup.</p></div>';return;}
   visible.forEach(x=>{
     const el=document.createElement('article');el.className='item';
     const h=document.createElement('h3');h.textContent=x.title;
     const tag=document.createElement('span');tag.className='tag';tag.textContent=x.category;
     const p=document.createElement('p');p.textContent=x.details;
     el.append(tag,h,p);
     if(session){const del=document.createElement('button');del.className='secondary';del.textContent='Delete';del.style.marginTop='12px';del.onclick=()=>removeItem(x.id);el.append(del);}
     items.append(el);
   });
 }
 async function load(){
   if(!configured){showStatus('Setup required: add your Supabase URL and anon key in config.js, then create the database table.');render();return;}
   client=window.supabase.createClient(window.QC_CONFIG.SUPABASE_URL,window.QC_CONFIG.SUPABASE_ANON_KEY);
   const {data,error}=await client.from('qc_standards').select('*').eq('published',true).order('created_at',{ascending:false});
   if(error){showStatus('Could not load standards: '+error.message);return;}
   standards=data||[];showStatus(standards.length+' published standard(s)');render();
   const {data:s}=await client.auth.getSession();session=s.session;updateAdmin();
 }
 function updateAdmin(){panel.classList.toggle('hidden',!session);$('loginBtn').textContent=session?'Admin Signed In':'Admin Login';render();}
 $('search').addEventListener('input',render);
 $('loginBtn').onclick=async()=>{
   if(!configured){showStatus('Complete Supabase setup first.');return;}
   const email=prompt('Admin email');if(!email)return;
   const password=prompt('Admin password');if(!password)return;
   const {data,error}=await client.auth.signInWithPassword({email,password});
   if(error){alert(error.message);return;}session=data.session;updateAdmin();
 };
 $('logoutBtn').onclick=async()=>{await client.auth.signOut();session=null;updateAdmin();};
 $('standardForm').onsubmit=async e=>{
   e.preventDefault();if(!session)return;
   const row={title:$('title').value.trim(),category:$('category').value,details:$('details').value.trim(),published:$('published').checked,created_by:session.user.id};
   const {error}=await client.from('qc_standards').insert(row);
   if(error){alert(error.message);return;}
   e.target.reset();$('published').checked=true;await load();showStatus('Standard published successfully.');
 };
 async function removeItem(id){
   if(!confirm('Delete this standard?'))return;
   const {error}=await client.from('qc_standards').delete().eq('id',id);
   if(error){alert(error.message);return;}await load();
 }
 load();
})();
