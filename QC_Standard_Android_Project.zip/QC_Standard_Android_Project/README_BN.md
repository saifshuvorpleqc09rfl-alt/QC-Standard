# QC Standard – Ceiling Fan (Android APK starter)

এটি একটি বিনামূল্যের Android APK project starter। এখানে এখনো APK তৈরি হয়নি; GitHub Actions দিয়ে Debug APK build করার workflow রাখা হয়েছে।

## কী আছে
- Ceiling Fan QC Standards দেখার public screen
- Admin sign-in এবং Standard add/edit/delete UI
- Supabase database integration (free tier ব্যবহার করা যায়)
- Android WebView wrapper
- GitHub Actions workflow দিয়ে APK build

## গুরুত্বপূর্ণ
আপনার আগের চ্যাটে দেওয়া password নিরাপদ নয়। সেটি অ্যাপে hard-code করা হয়নি। Supabase Auth-এ নতুন, গোপন Admin password তৈরি করুন।

## ১) Supabase বিনামূল্যে সেটআপ
1. https://supabase.com এ free project তৈরি করুন।
2. SQL Editor-এ `supabase/schema.sql` ফাইলের SQL চালান।
3. Project Settings → API থেকে Project URL এবং anon/public key নিন।
4. `app/src/main/assets/www/config.js` ফাইলে `SUPABASE_URL` ও `SUPABASE_ANON_KEY` বসান।
5. Authentication → Users থেকে Admin user তৈরি করুন। শুধু আপনার Admin email/password ব্যবহার করবেন।

## ২) APK build
1. এই ZIP GitHub-এ নতুন repository হিসেবে upload করুন।
2. GitHub repository-তে Actions চালু রাখুন।
3. `Build Android APK` workflow চালান (Actions tab)।
4. Build শেষ হলে workflow-এর Artifacts থেকে `QC-Standard-debug-apk` download করুন।
5. APK Android ফোনে install করুন। Android-এ unknown app install permission চাইতে পারে।

## ৩) Standard যোগ
Admin login করে Add Standard ব্যবহার করুন। অন্যরা login ছাড়াই published standards দেখতে পারবে।

## নিরাপত্তা
- `anon/public` key অ্যাপে রাখা যায়; এটি public key, secret service-role key কখনো অ্যাপে দেবেন না।
- Admin account শুধু Supabase Auth-এ তৈরি করুন।
- Supabase RLS policy অনুযায়ী কেবল authenticated admin-ই add/edit/delete করতে পারবে।
- Production release/signing এবং Play Store publishing এই starter-এর বাইরে।
